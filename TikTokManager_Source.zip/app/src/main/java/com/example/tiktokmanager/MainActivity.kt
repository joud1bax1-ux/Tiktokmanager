package com.example.tiktokmanager

import android.app.Activity
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val purple = 0xFF6750A4.toInt()
    private val ink = 0xFF202124.toInt()
    private val muted = 0xFF666A73.toInt()
    private val surface = 0xFFF0EDF6.toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFFF8F7FB.toInt()
        window.navigationBarColor = 0xFFF8F7FB.toInt()
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 28)
            setBackgroundColor(0xFFF8F7FB.toInt())
        }
        page.addView(text("TikTok Manager", 27, ink, true))
        page.addView(text("لوحة التحكم التجريبية", 14, muted, false).top(5))
        page.addView(metrics())
        page.addView(section("إعدادات النشر"))
        page.addView(card("فترة النشر", "15:00 — 03:00"))
        page.addView(card("الحسابات المستهدفة", "50 حساباً (هدف المشروع)"))
        page.addView(card("الفيديوهات اليومية", "3 لكل حساب — 150 يومياً"))
        page.addView(section("مصدر الفيديوهات"))
        page.addView(card("Google Drive", "الربط غير مفعّل في هذه النسخة"))
        page.addView(section("حالة النظام"))
        page.addView(card("النشر", "غير متصل — لا يتم نشر أي فيديو"))
        page.addView(card("الحذف التلقائي", "متوقف لحماية ملفاتك"))
        page.addView(text(
            "هذه نسخة أولية للواجهة فقط. لا تدخل كلمات مرور TikTok هنا. " +
            "ربط Drive والنشر يحتاجان تطويراً إضافياً وصلاحيات TikTok الرسمية.",
            12, muted, false
        ).top(18))
        setContentView(ScrollView(this).apply { addView(page) })
    }

    private fun metrics(): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 22, 0, 12)
        }
        row.addView(metric("50", "حساباً"))
        row.addView(metric("150", "فيديو يومياً"))
        return row
    }

    private fun metric(number: String, caption: String): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(12, 18, 12, 18)
            setBackgroundColor(surface)
            addView(text(number, 28, purple, true))
            addView(text(caption, 12, muted, false).top(4))
        }
        box.layoutParams = LinearLayout.LayoutParams(0, -2, 1f).apply {
            marginEnd = 8
        }
        return box
    }

    private fun section(value: String) = text(value, 17, ink, true).top(20)

    private fun card(title: String, value: String): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
            setBackgroundColor(0xFFFFFFFF.toInt())
            addView(text(title, 13, muted, false))
            addView(text(value, 16, ink, true).top(5))
        }
        box.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = 8 }
        return box
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean) =
        TextView(this).apply {
            text = value
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            textDirection = View.TEXT_DIRECTION_FIRST_STRONG
        }

    private fun View.top(dp: Int): View {
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = (dp * resources.displayMetrics.density).toInt()
        }
        return this
    }
}
